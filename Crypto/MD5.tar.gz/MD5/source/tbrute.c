#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <string.h>
#include "md5.h"

/**
*	Carattere di inizio: 0x20 (SPACE)
*	Carattere di fine:   0x7e (tilde)
*	Perchè funzioni __END al massimo può essere 0xF0
**/

#define __START		0X20
#define __END		0x7e

#define NUM_THREADS 5

#define _STOPPED	1
#define _FINISHED	2

static unsigned char *hash;
static int lb;
static int ub;

int found = 0;

/**
*	Funzione di supporto (esponenziale)
**/

long long int expn(int base, int e){

	long long result = 1;

	if(e < 0)
		return result;
	while(e--){
		result*=base;
	}
	return result;
}

/**
*	Controlla se l'hash in ingresso è un hash MD5
*	e lo converte in esadecimale (due caratteri formano un valore esadecimale a due cifre)
**/
unsigned char *checkANDconvert(char *hash){

	int i, j;

	unsigned char *ok_hash = (unsigned char *) calloc(16, sizeof(unsigned char));

	if(strlen(hash) != 32)
		return NULL;

	for(i = 0; i < 32; i++){
	
		j = (i > 0) ? (i % 2) ? j : j+1 : 0;

		if(hash[i] >= 0x30 && hash[i] <= 0x39)
			ok_hash[j] += (i % 2) ? ( (hash[i] - 0x30) & 0x0F) : ( (hash[i] - 0x30) & 0x0F) * 0x10;
		else if(hash[i] >= 0x41 && hash[i] <= 0x46)
			ok_hash[j] += (i % 2) ? (hash[i] -0x41 + 0xA) : (hash[i] - 0x41 + 0xA) * 0x10;
		else if(hash[i] >= 0x61 && hash[i] <= 0x66)
			ok_hash[j] += (i % 2) ? (hash[i] -0x61 + 0xA) : (hash[i] - 0x61 + 0xA) * 0x10;

		else {
			return NULL;		
		}
	}
	
	return ok_hash;
}

/**
*	Funzione di calcolo MD5
*	e controllo
**/
int MD5check (char *inString)
{
	int i = 0;
	MD5_CTX mdContext;
	unsigned int len = strlen (inString);

	//Calcolo MD5
	MD5Init (&mdContext);
	MD5Update (&mdContext, inString, len);
	MD5Final (&mdContext);
	
	//Controllo se il risultato è uguale all'hash in ingresso
	while (i < 16){
		if(mdContext.digest[i] != hash[i++])
			return 0;
	}
	return 1;
}

/**
*	Funzione forza bruta (genera tutte le combinazioni di caratteri di lunghezza da lb a ub)
*	Di ogni combinazione è calcolato l'hash e confrontato con l'hash da trovare
**/
void *brutal (void *args)
{
	int i, j, k, c, ok;
	int ID = (int) args;
	long long max;
	unsigned char force[ub+1];

	for(i = lb; i <= ub; i++){	//Un ciclo per ogni lunghezza di password

		force[0] = __START + ID;										 //Ogni thread comincia da START+ID e incrementa dello stesso valore. In questo modo
																								//ogni thread analizza stringhe differenti
		for(j = 1; j < i; j++) force[j] = __START; //Inizializzo a __START tutto il vettore delle combinazioni
		force[i] = '\0';													//E a zero l'ultimo

		max = expn((__END - __START), i);

		printf("THREAD %d) Start length  %d (%lld combination)\n", ID, i, max / NUM_THREADS);

		c = 0;
		ok = 1;

		while (ok)
		{

			if( MD5check(force) ){				//Controllo se l'MD5 della stringa corrente corrisponde
				printf("\nTHREAD %d) Found!!! STRING = %s\n", ID, force);
				found = 1;									//Comunico agli altri thread che la stringa è stata trovata
				pthread_exit(NULL);
			}

			force[0] += NUM_THREADS;		//Incremento la stringa
			c += NUM_THREADS;

			if(c >= ( __END+1 - __START)){	//Controlli da eseguire quando incremento sufficienti volte da dover applicare il riporto

					if(found)		//Se il carattere è stato trovato sospendo l'esecuzione
						pthread_exit((void *) _STOPPED);

				for (k = 0; k <= i; k++)		//Controllo dove ho superato il limite e quindi dove devo incrementare
				{
					if (force[k] > __END){
			      
						force[k] = (k) ? __START : __START + ID; //Setto al valore iniziale la cella che aveva superato il massimo
						force[k+1]++;														//Riporto della somma

						if(k+1 == i){						//Se ho incrementato il carattere di fine stringa vuol dire che ho controllato tutte le stringhe
							ok = 0;
						}
					}
					c = 0;
				}
			}

		}
	}

	printf("THREAD %d) Finished work with no result. FAIL\n", ID);
	pthread_exit((void *) _FINISHED);

}

int main (int argc, char *argv[])
{
	int i, rc;
	unsigned long long tm = time(NULL);

	//Creo il vettore dei Thread
	pthread_t threads[NUM_THREADS];
	pthread_attr_t attr;
	void *status;

	//inizializzo gli attributi per poter eseguire il join dei thread
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

	hash = (unsigned char *) calloc(16, sizeof(unsigned char));

	if (argc != 4){
		printf("Usage: md5brute <min-length> <max-length> <hash>\n\n");
		exit(1);
	}

	lb = atoi(argv[1]);
	if(lb <= 0)
		lb = 1;

	ub = atoi(argv[2]);
	if(ub < lb)
		ub = lb;

	//Check dell'hash in ingresso
	hash = checkANDconvert(argv[3]);
	if(hash == NULL){
		printf("ERROR; bad format in hash code\n");
		exit(1);
	}

	//Inizio del lavoro
	for(i = 0; i < NUM_THREADS; i++){
		rc = pthread_create(&threads[i], &attr, brutal, (void *) i);
		if (rc){
			printf("ERROR; creating thread\n");
			exit(-1);
		}
	}

	pthread_attr_destroy(&attr);
	
	//Join()
	for(i=0; i<NUM_THREADS; i++)
	{
		rc = pthread_join(threads[i], &status);
		if (rc)
		{
			printf("ERROR; joining thread\n");
			exit(-1);
		}
	}

	//Stampo il tempo di completamento
	printf("\nComputation time: %lld [s]\n", (time(NULL) - tm));
	pthread_exit(NULL);

}
