/***
**	Title: Criptatore.c
**	Author: Bellavista Daniele
**	Version: 1.1
     Copyright (c)   2010   Daniele Bellavista
     è garantito il permesso di copiare, distribuire e/o modificare
     questo documento seguendo i termini della Licenza per
     Documentazione Libera GNU, Versione 1.1 o ogni versione
     successiva pubblicata dalla Free Software Foundation;
		 con le Sezioni Non Modificabili Author, nessun Testo Copertina,
		 nessun Testo di Retro Copertina; Una copia della licenza è 
		 acclusa nella sezione intitolata "Licenza per Documentazione
		 Libera GNU".

***/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <pthread.h>

#define MAX_BUFF 8000
#define N 4

void *compute(void* args);

char input[100];			//Il nome del file di input
char output[100];			//Il nome del file di input
unsigned char bmask[4];	//La maschera di byte
int all = 0;

struct info{
	int id;									//Id del thread
	long start;							//La posizione da cui partire
	long end;								//La posizione in cui terminare
};

int main(int argv, char** argc){
	
	int n, i, rc;
	long range, inputLength;
	unsigned int mask;
	FILE *in, *out;
	struct info* info = (struct info *) malloc(N*sizeof(struct info));
	unsigned long long init;

	//Creo il vettore dei Thread
	pthread_t threads[N];
	pthread_attr_t attr;
	void *status;

	//inizializzo gli attributi per poter eseguire il join dei thread
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

	init = time (NULL);
	
	if(argv < 4){
		printf("\nUsage: compute inputFileName OutputFileName Mask\n\nQuesto programma crittografa il file di ingresso InputFileName,\ncon la maschera Mask (intero),\ncreando il file di uscita OutputFileName\n\n");
		exit(0);
	}

	if( !strcmp(argc[1], argc[2]) ){
		printf("\nError: input and output file are the same\n");
		exit(0);
	}

	//Testo il file di ingresso
	in = fopen(argc[1], "r");
	if(in == NULL){
		printf("\nError opening input file\n");
		exit(errno);
	}
	//Prendo la dimensione del file di input
	fseek(in, 0, SEEK_END);	
	inputLength = ftell(in);
	fclose(in);

	//Creo il file di uscita
	out = fopen(argc[2], "w");
	if(out == NULL){
		printf("\nError creating output file\n");
		exit(errno);
	}
	fclose(out);

	//Elaboro la maschera
	mask = atoi(argc[3]);
	bmask[0] = mask;
	mask >>= 8;
	bmask[1] = mask;
	mask >>= 8;
	bmask[2] = mask;
	mask >>= 8;
	bmask[3] = mask;
	
	//Copio il path di input nella struttura che sarà letta dai thread
	strcpy(input, argc[1]);
	strcpy(output, argc[2]);

	//Creo i thread
	range = inputLength / N;
	
	for (i = 0; i < N - 1; i++) {
		info[i].id = i;
		info[i].start = (range * i);
		info[i].end = (range * (i + 1));
		rc = pthread_create(&threads[i], &attr, compute, (void *) &info[i]);
		if (rc){
			printf("ERROR; creating thread\n");
			exit(-1);
		}
	}
	info[N-1].id = N-1;
	info[N-1].start = (range * (N-1) );
	info[N-1].end = inputLength;
	rc = pthread_create(&threads[N-1], &attr, compute, (void *) &info[N-1]);
	if (rc){
			printf("ERROR; creating thread\n");
			exit(-1);
	}

	pthread_attr_destroy(&attr);

	//Aspetto i thread per andare a capo (solo per mera estetica)
	while(all < N);
	printf("\n");
	
	//Join dei thread
	for (i = 0; i < N; i++) {
		rc = pthread_join(threads[i], &status);
		if (rc)
		{
			printf("ERROR; joining thread\n");
			exit(-1);
		}
	}

	//Stampo i secondi passati
	printf("Terminato in %lld secondi",(time(NULL)-init));
	pthread_exit(NULL);
}


void *compute(void* args){

	FILE *in, *out;
	char buff[MAX_BUFF];
	long long int cursor, cursor2, MaskByteNumber, i;
	int dataLengthRed, j;
	struct info* info = (struct info*) args;

	printf("%d) Inizio\n",info->id, info->start, info->end);
	all++;

	//Apro il file di input ed output
	in = fopen(input, "r");
	out = fopen(output, "a");
	//...e posiziono l'indice dove devo iniziare a lavorare

	fseek(in, info->start, SEEK_SET);
	fseek(out, info->start, SEEK_SET);

	//Eseguo il lavoro
	for (i = 0; i < (info->end - info->start);)
	{
		//Quantità di dati da leggere
		if ( (info->end - info->start - i) >= MAX_BUFF) {
			dataLengthRed = MAX_BUFF;
		} else {                    //Se non posso riempire interamente il buffer vuol dire che è l'ultima iterazione da fare
			dataLengthRed = (int) (info->end - info->start - i);
		}
		
		//Determino a seconda del file pointer qual è il byte della maschera con cui iniziare
		MaskByteNumber = (ftell(in) % 4);

		//Leggo i dati
		fread(buff, 1, dataLengthRed, in);

		for (j = 0; j < dataLengthRed; j++) {
			//maschero ogni byte con il mask[MaskByteNumber]
			buff[j] ^= bmask[MaskByteNumber];
			//Incremento il MaskByteNumber
			MaskByteNumber = (MaskByteNumber == 3) ? 0 : MaskByteNumber+1;
			//Incremento il numero di byte letti
			i++;
		}
		//Scrivo in output i dati crittografati
		fwrite(buff, 1, dataLengthRed, out);

	}

	fclose(in);
	fclose(out);

	printf("%d) Finito\n",info->id);
	pthread_exit(NULL);
}
